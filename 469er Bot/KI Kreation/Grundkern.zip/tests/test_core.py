import json
import tempfile
import threading
import unittest
from http.client import HTTPConnection
from pathlib import Path
from threading import Event

from ai_core.agents import AniForge, Visionary, YinAndYang
from ai_core.approvals import ApprovalManager, ApprovalStatus, PatchProposal
from ai_core.api import create_server
from ai_core.code_proposals import CodeProposalService
from ai_core.config import load_language_config
from ai_core.language import (
    LanguageService,
    OllamaProvider,
    OpenAICompatibleProvider,
    _NoRedirect,
    provider_from_environment,
)
from ai_core.knowledge import KnowledgeStore
from ai_core.providers import MockProvider
from ai_core.service import CoreService


class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = KnowledgeStore(Path(self.temp.name) / "knowledge.sqlite3")

    def tearDown(self):
        self.temp.cleanup()

    def test_only_confirmed_non_secret_knowledge_is_stored(self):
        with self.assertRaises(PermissionError):
            self.store.add_confirmed("finding", "unconfirmed")
        with self.assertRaises(ValueError):
            self.store.add_confirmed("finding", "api_key=example-secret", confirmed=True)
        item_id = self.store.add_confirmed(
            "decision", "Use local SQLite.", confirmed=True
        )
        self.assertEqual(self.store.list_confirmed()[0]["id"], item_id)
        self.assertTrue(self.store.health_check())

    def test_weekly_report_is_saved_with_source_and_retrieval_time(self):
        service = CoreService(str(Path(self.temp.name) / "reports.sqlite3"))
        report = service.visionary_report.generate_weekly(
            [
                {
                    "source": "https://example.test/updates",
                    "retrieved_at": "2026-11-05T12:00:00Z",
                    "summary": "A source update, supplied by the caller.",
                }
            ]
        )
        self.assertIn("https://example.test/updates", report["content"])
        self.assertIn("2026-11-05T12:00:00Z", report["content"])
        with service.store._connect() as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM weekly_reports").fetchone()[0], 1)
        with self.assertRaises(ValueError):
            service.visionary_report.generate_weekly(
                [{"source": "https://example.test", "retrieved_at": "yesterday", "summary": "x"}]
            )


class ApprovalTests(unittest.TestCase):
    def test_action_tiers_and_patch_proposals(self):
        approvals = ApprovalManager()
        self.assertEqual(approvals.authorize("analyze"), ApprovalStatus.ALLOWED)
        self.assertEqual(approvals.authorize("test"), ApprovalStatus.APPROVAL_REQUIRED)
        self.assertEqual(
            approvals.authorize("test", explicitly_allowed=True, isolated=True),
            ApprovalStatus.ALLOWED,
        )
        self.assertEqual(
            approvals.authorize("modify_files", approved=True), ApprovalStatus.ALLOWED
        )
        self.assertEqual(
            approvals.authorize("delete_data", approved=True), ApprovalStatus.FORBIDDEN
        )
        proposal = PatchProposal("diff --git ...")
        self.assertEqual(proposal.status, ApprovalStatus.APPROVAL_REQUIRED)


class AgentTests(unittest.TestCase):
    def test_roles_and_ani_forge_are_separate(self):
        general = YinAndYang()
        ani_forge = AniForge()
        self.assertIsNone(general.plan("task")["delegated_to"])
        self.assertFalse(ani_forge.production_actions_enabled)
        self.assertFalse(hasattr(ani_forge, "knowledge"))
        self.assertEqual(ani_forge.submit("request")["status"], "placeholder")
        options = Visionary().improvement_options("problem")
        self.assertEqual(len(options), 2)
        self.assertIn("creative", options[1].name.lower())
        self.assertEqual(
            Visionary().review("change", authored_by="Visionär")["status"],
            "needs_independent_reviewer",
        )

    def test_provider_is_explicitly_a_mock(self):
        self.assertIn("MOCK", MockProvider().generate("hello", timeout=1))
        self.assertEqual(MockProvider.name, "mock")


class CodeProposalTests(unittest.TestCase):
    def test_real_provider_output_is_a_non_applied_proposal(self):
        class DraftProvider:
            name = "test-provider"

            def draft_code(self, task, context, *, timeout):
                self.asserted = (task, context, timeout)
                return "def answer():\n    return 42\n"

        provider = DraftProvider()
        proposal = CodeProposalService(provider).create(
            "Write a helper", "Use a small pure function."
        )
        self.assertEqual(proposal.provider, "test-provider")
        self.assertEqual(proposal.status, "approval_required")
        self.assertFalse(proposal.applied)
        self.assertIn("return 42", proposal.content)
        self.assertEqual(provider.asserted[:2], ("Write a helper", "Use a small pure function."))
        self.assertGreater(provider.asserted[2], 0)

    def test_mock_disclosure_and_input_and_output_guards(self):
        proposal = CodeProposalService().create("Write a function")
        self.assertEqual(proposal.provider, "mock")
        self.assertIn("MOCK", proposal.content)
        self.assertFalse(proposal.applied)
        with self.assertRaises(ValueError):
            CodeProposalService().create("api_key=do-not-send")
        with self.assertRaises(ValueError):
            CodeProposalService().create("Write code", "access_token=hidden")

        class SecretProvider:
            name = "test"

            def draft_code(self, task, context, *, timeout):
                return "secret=leaked"

        with self.assertRaises(ValueError):
            CodeProposalService(SecretProvider()).create("Write code")


class LanguageTests(unittest.TestCase):
    def test_yaml_config_has_requested_model_and_prompt(self):
        config = load_language_config(Path(__file__).parents[1] / "config.yaml")
        self.assertEqual(config.model, "llama3.1:8b")
        self.assertEqual(
            config.system_prompt,
            "Du bist ein hilfreicher Assistent. Antworte knapp und auf Deutsch.",
        )
        self.assertEqual(config.provider, "ollama")
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        invalid_config = Path(temp.name) / "config.yaml"
        invalid_config.write_text("- not-a-mapping\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            load_language_config(invalid_config)

    def test_ollama_provider_streams_text_with_system_prompt(self):
        provider = OllamaProvider(
            endpoint="http://127.0.0.1:11434",
            model="llama3.1:8b",
            timeout_seconds=20,
        )

        class FakeResponse:
            def __init__(self):
                self.lines = iter(
                    [
                        b'{"message":{"content":"Guten "},"done":false}\n',
                        b'{"message":{"content":"Tag"},"done":true}\n',
                    ]
                )

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return None

            def readline(self, limit):
                return next(self.lines, b"")

        class FakeOpener:
            def open(self, request, timeout):
                self.request = request
                self.timeout = timeout
                return FakeResponse()

        opener = FakeOpener()
        provider._opener = opener
        chunks = list(
            provider.stream(
                "Sag Hallo", system_prompt="Antworte auf Deutsch.", timeout=5
            )
        )
        self.assertEqual(chunks, ["Guten ", "Tag"])
        payload = json.loads(opener.request.data)
        self.assertEqual(payload["model"], "llama3.1:8b")
        self.assertTrue(payload["stream"])
        self.assertEqual(payload["messages"][0]["content"], "Antworte auf Deutsch.")
        self.assertEqual(opener.timeout, 5)

    def test_external_provider_is_disabled_by_default_and_requires_opt_in(self):
        self.assertEqual(provider_from_environment({}).name, "mock")
        with self.assertRaises(ValueError):
            provider_from_environment({"AI_LANGUAGE_PROVIDER": "openai-compatible"})
        provider = provider_from_environment(
            {
                "AI_LANGUAGE_PROVIDER": "openai-compatible",
                "AI_LANGUAGE_EXTERNAL_ENABLED": "true",
                "AI_LANGUAGE_ENDPOINT": "https://provider.example/v1/chat/completions",
                "AI_LANGUAGE_MODEL": "example-model",
                "AI_LANGUAGE_API_KEY": "test-token",
            }
        )
        self.assertEqual(provider.name, "openai-compatible:example-model")

    def test_external_provider_sends_bounded_request_without_redirects(self):
        provider = OpenAICompatibleProvider(
            endpoint="https://provider.example/v1/chat/completions",
            model="example-model",
            api_key="test-token",
        )

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return None

            def read(self, limit):
                self.limit = limit
                return b'{"choices":[{"message":{"content":"Hallo"}}]}'

        class FakeOpener:
            def open(self, request, timeout):
                self.request = request
                self.timeout = timeout
                return FakeResponse()

        opener = FakeOpener()
        provider._opener = opener
        self.assertEqual(provider.generate("Guten Tag", timeout=2), "Hallo")
        self.assertEqual(
            opener.request.get_header("Authorization"), "Bearer " + "test-token"
        )
        self.assertEqual(opener.timeout, 2)
        self.assertNotIn("test-token", opener.request.data.decode())
        self.assertIsNone(
            _NoRedirect().redirect_request(
                None, None, 302, "", {}, "https://other.example/"
            )
        )

    def test_language_service_rejects_secret_prompts_and_discloses_mock(self):
        service = LanguageService()
        self.assertIn("MOCK", service.generate("hello"))
        with self.assertRaises(ValueError):
            service.generate("api_key=not-a-real-key")
        with self.assertRaises(ValueError):
            OpenAICompatibleProvider(
                endpoint="http://provider.example/chat",
                model="model",
                api_key="test-token",
            )


class LifecycleTests(unittest.TestCase):
    def test_stop_rejects_new_tasks_and_waits_for_active_work(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        service = CoreService(str(Path(temp.name) / "lifecycle.sqlite3"))
        entered, release = Event(), Event()

        class BlockingProvider:
            name = "test"

            def generate(self, prompt, *, timeout):
                entered.set()
                release.wait(timeout=min(timeout, 2))
                return "done"

        service.coordinator.provider = BlockingProvider()
        service.start()
        worker = threading.Thread(target=service.submit_task, args=("test task",))
        worker.start()
        self.assertTrue(entered.wait(timeout=1))
        self.assertFalse(service.stop(timeout=0))
        with self.assertRaises(RuntimeError):
            service.submit_task("new task")
        release.set()
        worker.join(timeout=2)
        self.assertFalse(worker.is_alive())
        self.assertTrue(service.stop(timeout=1))


class APITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        service = CoreService(str(Path(self.temp.name) / "api.sqlite3"))
        self.service = service
        self.server = create_server(service, port=0)
        self.thread = threading.Thread(target=self.server.serve_forever)
        self.thread.start()
        self.connection = HTTPConnection("127.0.0.1", self.server.server_address[1])

    def tearDown(self):
        self.connection.close()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.temp.cleanup()

    def test_health_and_task_submission(self):
        self.connection.request("GET", "/health")
        response = self.connection.getresponse()
        self.assertEqual(response.status, 200)
        health = json.loads(response.read())
        self.assertTrue(health["accepting_tasks"])
        self.assertEqual(health["language_provider"], "mock")

        self.connection.request(
            "POST", "/language", body=json.dumps({"prompt": "Hello"}),
            headers={"Content-Type": "application/json"},
        )
        response = self.connection.getresponse()
        language_result = json.loads(response.read())
        self.assertEqual(language_result["provider"], "mock")
        self.assertIn("MOCK", language_result["response"])

    def test_language_stream_endpoint_returns_plain_text_chunks(self):
        class StreamingProvider:
            name = "test-stream"

            def generate(self, prompt, *, timeout):
                return "unused"

            def stream(self, prompt, *, system_prompt, timeout):
                self.last_request = (prompt, system_prompt, timeout)
                yield "Guten "
                yield "Tag"

        provider = StreamingProvider()
        self.service.language.provider = provider
        self.connection.request(
            "POST",
            "/language/stream",
            body=json.dumps({"prompt": "Sag Hallo"}),
            headers={"Content-Type": "application/json"},
        )
        response = self.connection.getresponse()
        self.assertEqual(response.status, 200)
        self.assertEqual(response.getheader("Content-Type"), "text/plain; charset=utf-8")
        self.assertEqual(response.getheader("Transfer-Encoding"), "chunked")
        self.assertEqual(response.read(), "Guten Tag".encode())
        self.assertEqual(provider.last_request[0], "Sag Hallo")

        self.service.language.provider = MockProvider()
        self.connection.request(
            "POST", "/tasks", body=json.dumps({"task": "Plan a small change."}),
            headers={"Content-Type": "application/json"},
        )
        response = self.connection.getresponse()
        payload = json.loads(response.read())
        self.assertEqual(response.status, 200)
        self.assertEqual(payload["provider"], "mock")
        self.assertIn("MOCK", payload["response"])

    def test_weekly_report_api_and_source_validation(self):
        body = {
            "sources": [
                {
                    "source": "https://example.test/weekly",
                    "retrieved_at": "2026-11-05T12:00:00Z",
                    "summary": "Caller-supplied snapshot.",
                }
            ]
        }
        self.connection.request(
            "POST", "/reports/weekly", body=json.dumps(body),
            headers={"Content-Type": "application/json"},
        )
        response = self.connection.getresponse()
        report = json.loads(response.read())
        self.assertEqual(response.status, 201)
        self.assertIn("2026-11-05T12:00:00Z", report["content"])

    def test_code_proposal_endpoint_never_applies_mock_draft(self):
        self.connection.request(
            "POST",
            "/proposals/code",
            body=json.dumps({"task": "Write a helper"}),
            headers={"Content-Type": "application/json"},
        )
        response = self.connection.getresponse()
        proposal = json.loads(response.read())
        self.assertEqual(response.status, 200)
        self.assertEqual(proposal["status"], "approval_required")
        self.assertEqual(proposal["provider"], "mock")
        self.assertFalse(proposal["applied"])
        self.assertIn("MOCK", proposal["content"])
        self.assertFalse(list(Path(self.temp.name).glob("*.py")))

    def test_malformed_task_and_stop(self):
        self.connection.request(
            "POST", "/tasks", body=json.dumps({"task": "api_key=not-a-secret"}),
            headers={"Content-Type": "application/json"},
        )
        response = self.connection.getresponse()
        self.assertEqual(response.status, 400)
        response.read()
        self.connection.request("POST", "/stop", body=b"")
        response = self.connection.getresponse()
        self.assertEqual(response.status, 200)
        response.read()
        self.connection.request(
            "POST", "/tasks", body=json.dumps({"task": "later"}),
            headers={"Content-Type": "application/json"},
        )
        response = self.connection.getresponse()
        self.assertEqual(response.status, 503)
        response.read()


if __name__ == "__main__":
    unittest.main()
